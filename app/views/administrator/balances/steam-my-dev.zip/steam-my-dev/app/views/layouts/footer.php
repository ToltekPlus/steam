<footer class="columns is-full is-centered is-vertical">
    <div class="column is-8">
        <div class="columns">
            <div class="column is-3">
                          <span class="icon logotype">
                            <ion-icon name="logo-steam"></ion-icon>
                          </span>
            </div>

            <div class="column is-3">
                <a href="">Что такое Steam</a>
            </div>

            <div class="column is-3">
                <a href="">Сообщество</a>
            </div>

            <div class="column is-3">
                <a href="">Пресс-релизы</a>
            </div>
        </div>
    </div>
</footer>

<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script type="text/javascript" src="../js/bundle.js"></script>
</body>
</html>